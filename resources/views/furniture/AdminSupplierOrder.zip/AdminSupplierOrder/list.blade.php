@extends('layouts.layout')
@section('title', 'Supplier List')
@section('content')
    <!-- main -->
    <main>

        <div class="container">
            <!-- breadcrumb -->
            <div class="row align-items-center">
                <div class="col-12 col-md-4">
                    <div class="page-titles">
                        <h4>Capture Select Supplier</h4>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                            {{-- <li class="breadcrumb-item"><a href="{{ route('school-maintenance') }}">School Maintenance</a></li> --}}
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Delivery List</a></li>
                        </ol>
                    </div>
                </div>
                {{-- <div class="offset-xl-3 col-12 col-md-4 col-xl-2 mb-3">
                    <a href="{{ route('Deliverys.Add') }}" class="btn btn-primary w-100">+ Upload Delivery Note</a>
                </div> --}}
                <div class="col-12 col-md-4 col-xl-3 mb-3">
                    <div id="search-btn">
                        <form class="d-flex" method="GET" action="{{ route('membersupplier.search') }}">
                            <input type="search" name="query" class="form-control border-0 shadow-none"
                                value="{{ old('query') }}" placeholder="Search">
                            <button type="submit" class="btn-reset color-primary shadow-none">
                                <i class="ri-search-line fs-2"></i>
                            </button>
                        </form>
                    </div>
                    @if ($errors->has('query'))
                        <span class="text-danger" role="alert">
                            <strong>{{ $errors->first('query') }}</strong>
                        </span>
                    @endif
                </div>
            </div>

            <div class="row">

                @if ($message = Session::get('success'))
                    <div class="modal fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        style="display: block;" aria-modal="true" role="dialog">
                        <div class="modal-dialog modal-dialog-centered popup-alert">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="text-center">
                                        <img src="{{ asset('img/popup-check.svg') }}" class="img-fluid mb-5" alt="">
                                        <h4 class="popup-alert_title">{{ $message }}</h4>
                                        {{-- <p class="popup-alert_des">{{ $message }}</p> --}}
                                    </div>

                                </div>
                                <div class="modal-footer text-center justify-content-center p-3 border-0">
                                    <button type="button" class="btn btn-secondary px-5" data-bs-dismiss="modal"
                                        onclick="hidePopup()">OK</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif



                @if ($message = Session::get('successD'))
                    <div class="modal fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        style="display: block;" aria-modal="true" role="dialog">
                        <div class="modal-dialog modal-dialog-centered popup-alert">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="text-center">
                                        <img src="{{ asset('img/popup-check.svg') }}" class="img-fluid mb-5" alt="">
                                        <h4 class="popup-alert_title">{{ $message }}</h4>
                                        {{-- <p class="popup-alert_des">{{ $message }}</p> --}}
                                    </div>

                                </div>
                                <div class="modal-footer text-center justify-content-center p-3 border-0">
                                    <button type="button" class="btn btn-secondary px-5" data-bs-dismiss="modal"
                                        onclick="hidePopup()">OK</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

                @if ($message = Session::get('errorMessage'))
                    <div class="modal fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        style="display: block;" aria-modal="true" role="dialog">
                        <div class="modal-dialog modal-dialog-centered popup-alert">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="text-center">
                                        <img src="{{ asset('img/Error-Text.svg') }}" class="img-fluid mb-5" alt="">
                                        <h4 class="popup-alert_title">{{ $message }}</h4>
                                        {{-- <p class="popup-alert_des">{{ $message }}</p> --}}
                                    </div>

                                </div>
                                <div class="modal-footer justify-content-around text-center">
                                    <button type="button" class="btn btn-secondary px-5" data-bs-dismiss="modal"
                                        onclick="hidePopup()">OK</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

                @if ($message = Session::get('error'))
                    <div class="modal fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        style="display: block;" aria-modal="true" role="dialog">
                        <div class="modal-dialog modal-dialog-centered popup-alert">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="text-center">
                                        <img src="{{ asset('img/Error-Text.svg') }}" class="img-fluid mb-5"
                                            alt="">
                                        <h4 class="popup-alert_title">School Maintenance - School Circuit</h4>
                                        <p class="popup-alert_des">{{ $message }}</p>
                                    </div>

                                </div>
                                <div class="modal-footer text-center justify-content-center p-3 border-0">
                                    <button type="button" class="btn btn-secondary px-5" data-bs-dismiss="modal"
                                        onclick="hidePopup()">OK</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                @if ($message = Session::get('alert'))
                    <div class="modal fade show" id="exampleModalNew" tabindex="-1" aria-labelledby="exampleModalLabel"
                        style="display: block;" aria-modal="true" role="dialog">
                        <div class="modal-dialog modal-dialog-centered popup-alert">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="text-center">
                                        <img src="{{ asset('img/confirmation-popup.svg') }}" class="img-fluid mb-5"
                                            alt="">
                                        <h4 class="popup-alert_title">School Maintenance - School Circuit</h4>
                                        <p class="popup-alert_des">{{ $message }}</p>
                                    </div>

                                </div>
                                <div class="modal-footer text-center justify-content-center p-3 border-0">
                                    <button type="button" class="btn btn-secondary px-5" data-bs-dismiss="modal"
                                        onclick="hidePopup()">OK</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                <div class="col-12">
                    @if ($message = Session::get('searcherror'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            {{ $message }}
                        </div>
                    @endif
                    {{-- INSERT INTO `suppliyer`(`Id`, `email`, `CompanyName`, `CompanyAddress`, `CompanyContact`, `ISActive`, `Date`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]') --}}
                    <div class="table-responsive">
                        <table class="table">
                            <input type="text" name="user" value="{{ Auth::user()->organization }}">

                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Request Type</th> 
                                    <th>School Emis </th>
                                    <th>School  </th>

                                    <th>Company Name</th>
                                    <th>Contact Number</th>
                                    <th>Company Address</th>
                                    <th> Email</th>
                                    {{-- <th> Invioce</th> --}}
                                    {{-- <th> Date</th> --}}





                                    <th class="text-end">Manage</th>
                                </tr>
                            </thead>
                            @if (isset($data) && count($data) < 1)
                                <tbody>
                                    <tr class="text-center text-dark">
                                        <td colspan="7">No Supplier Found</td>
                                    </tr>
                                </tbody>
                            @else
                                @foreach ($data as $key => $supplier)
                                    <tbody>
                                        <tr>

                                            <td>{{ $supplier->Id }}</td>
                                             <td>Textbook</td>
                                             <td>5000989988</td>
                                             <td>BLACKBANK PRIMARY SCHOOL</td>

                                            <td>{{ $supplier->CompanyName }}</td>
                                            <td>{{ ucwords($supplier->CompanyContact) }}</td>
                                            <td>{{ ucwords($supplier->CompanyAddress) }}</td>
                                            <td>{{ ucwords($supplier->email) }}</td>
                                            {{-- <td> --}}
                                                {{-- C:\xampp\htdocs\Project\Textbook\public\public\ApprovePdf --}}
                                                {{-- @if ($supplier->FilePath)
                                                    <a href="{{ asset('public/Delivery/' . $supplier->FilePath) }}"
                                                        download>
                                                        <i class="fa fa-download"></i> Download File
                                                    </a>
                                                @else
                                                    <!-- Handle the case where 'documentRequest' is not available --> N/A
                                                @endif --}}
                                            {{-- </td> --}}
                                            {{-- <td>{{ $supplier->date }}</td> --}}
                                                <td>  <button type="button"   data-bs-toggle="modal" data-bs-target="#exampleModalNew">Capture</button>
                                                </td>
                                  
                                        </tr>
                                    </tbody>
                                @endforeach
                            @endif
                        </table>
                    </div>

                       
                     
                      
                    <nav class="pagination-wrap">
                        <ul class="pagination">
                            <li class="page-item ">
                                <a class="{{ $data->previousPageUrl() ? '' : 'disabled' }}"
                                    href="{{ $data->previousPageUrl() }}">
                                    <i class="ri-arrow-left-s-line me-4"></i>
                                    Previous</a>
                            </li>

                            <li class="page-item">
                                <a class="{{ $data->nextPageUrl() ? '' : 'disabled' }}"
                                    href="{{ $data->nextPageUrl() }}">Next
                                    <i class="ri-arrow-right-s-line ms-4"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        @if ($message = Session::get('success'))
            <div class="modal-backdrop fade show" onclick="hidePopup()"></div>
        @endif
        @if ($message = Session::get('error'))
            <div class="modal-backdrop fade show" onclick="hidePopup()"></div>
        @endif
        @if ($message = Session::get('alert'))
            <div class="modal-backdrop fade show" onclick="hidePopup()"></div>
        @endif
        <script>
            function hidePopup() {
                $("#exampleModal").fadeOut(200);
                $('.modal-backdrop').remove();
            }
        </script>
        
    </main>
@endsection
